Aplikasi Androngeng merupakan sebuah aplikasi berbasis android yang memiliki kriteria sebagai aplikasi hiburan . Androngeng dibuat untuk menghibur pengguna android khusus nya anak-anak dengan menyediakan dongeng-dongeng anak Indonesia beserta pesan moral yang ada di dalamnya.
Aplikasi ini dibuat dengan tujuan untuk memenuhi tugas besar mata kuliah Rekayasa Perangkat Lunak yang dibimbing oleh Bapak Jauharul Fuady.
Semoga aplikasi ini bermanfaat bagi para pengguna sekaligus pembuat nya.

Aplikasi bisa di download di http://www.mediafire.com/?c9ok6odxhx2lxf0

Panduan instalasi
 - setelah file selesai di download, file bisa di instal pada ponsel 	    bersistem operasi android
 - cara instalnya cukup dengan memilih (klik/tekan) androngeng.apk ikuti         instruksi yang ada.
 - setelah instalasi selesai dan berhasil, perangkat lunak ini siap digunakan

untuk informasi lebih detail silakan menghubungi ke dongenganakindonesia2@gmail.com