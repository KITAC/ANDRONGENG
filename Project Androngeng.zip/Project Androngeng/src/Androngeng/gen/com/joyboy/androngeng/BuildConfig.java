/** Automatically generated file. DO NOT MODIFY */
package com.joyboy.androngeng;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}